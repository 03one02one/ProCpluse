#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

void main() {
	ofstream fout("sale.txt");

	fout << "                      ";
	fout << "--------------�� ���� ����--------------" << endl;
	fout << "                      ";
	fout << "|		 			     |" << endl;
	fout << "                      ";
	fout << "|    	   ����ǰ �� ǰ��    	     |" << endl;
	fout << "                      ";
	fout << "|			                     |" << endl;
	fout << "                      ";
	fout << "|      	       8%!! ����             |" << endl;
	fout << "                      ";
	fout << "|			                     |" << endl;
	fout << "                      ";
	fout << "|    ���� ���� ProCpluse���� ������.   |" << endl;
	fout << "                      ";
	fout << "-----------------------------------------" << endl;
}